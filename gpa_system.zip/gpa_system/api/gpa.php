<?php
// ============================================================
// api/gpa.php — Student GPA API
// ============================================================

session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Semester.php';
require_once __DIR__ . '/../models/Course.php';
require_once __DIR__ . '/../models/Enrollment.php';
require_once __DIR__ . '/../models/Grade.php';
require_once __DIR__ . '/../models/GPA.php';

header('Content-Type: application/json');
requireRole('student');

$studentId = (int) $_SESSION['user_id'];
$action    = $_GET['action'] ?? '';

switch ($action) {

    // ----------------------------------------------------------
    // GET: active semester grades + GPA
    // ----------------------------------------------------------
    case 'current':
        $semester = Semester::getActive();

        if (!$semester) {
            echo json_encode(['error' => 'No active semester']);
            exit;
        }

        if (!Enrollment::exists($studentId, (int) $semester['id'])) {
            echo json_encode(['error' => 'Not enrolled in active semester']);
            exit;
        }

        $courses = Course::getBySemester((int) $semester['id']);
        foreach ($courses as &$course) {
            $g = Grade::get($studentId, (int) $course['id'], (int) $semester['id']);
            $course['grade']        = $g;
            $course['grade_points'] = $g !== null ? $g * (int) $course['credits'] : null;
        }

        $gpaRecord = GPA::get($studentId, (int) $semester['id']);
        $gpa       = $gpaRecord ? (float) $gpaRecord['gpa'] : null;

        echo json_encode([
            'semester' => $semester,
            'courses'  => $courses,
            'gpa'      => $gpa,
        ]);
        break;

    // ----------------------------------------------------------
    // GET: all semesters with grades + GPA (for Chart.js)
    // ----------------------------------------------------------
    case 'history':
        $semesters = Enrollment::getSemestersByStudent($studentId);

        foreach ($semesters as &$sem) {
            $sem['courses'] = Course::getBySemester((int) $sem['id']);
            foreach ($sem['courses'] as &$course) {
                $g = Grade::get($studentId, (int) $course['id'], (int) $sem['id']);
                $course['grade']        = $g;
                $course['grade_points'] = $g !== null ? $g * (int) $course['credits'] : null;
            }
            $gpaRecord  = GPA::get($studentId, (int) $sem['id']);
            $sem['gpa'] = $gpaRecord ? (float) $gpaRecord['gpa'] : null;
        }

        echo json_encode($semesters);
        break;

    // ----------------------------------------------------------
    // GET: stream CSV download
    // ----------------------------------------------------------
    case 'export':
        $rows = Grade::getAllWithDetailsByStudent($studentId);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="gpa_history.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Semester', 'Academic Year', 'Course', 'Credits', 'Grade', 'Grade Points']);

        foreach ($rows as $row) {
            fputcsv($out, [
                $row['semester_label'],
                $row['academic_year'],
                $row['course_name'],
                $row['credits'],
                $row['grade'],
                $row['grade'] * $row['credits'],
            ]);
        }

        fclose($out);
        exit;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action']);
}
