<?php
// ============================================================
// api/grades.php — Professor grade entry API
// ============================================================

session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Assignment.php';
require_once __DIR__ . '/../models/Enrollment.php';
require_once __DIR__ . '/../models/Grade.php';
require_once __DIR__ . '/../models/GPA.php';

header('Content-Type: application/json');
requireRole('professor');

$professorId = (int) $_SESSION['user_id'];
$action      = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {

    // ----------------------------------------------------------
    // GET: courses assigned to this professor for a semester
    // ----------------------------------------------------------
    case 'courses':
        $semId   = (int) ($_GET['semester_id'] ?? 0);
        $courses = Assignment::getCoursesByProfessorSemester($professorId, $semId);
        echo json_encode($courses);
        break;

    // ----------------------------------------------------------
    // GET: enrolled students + existing grades for a course
    // ----------------------------------------------------------
    case 'students':
        $semId    = (int) ($_GET['semester_id'] ?? 0);
        $courseId = (int) ($_GET['course_id']   ?? 0);

        if (!Assignment::exists($professorId, $courseId, $semId)) {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden']);
            exit;
        }

        $students = Enrollment::getStudentsBySemester($semId);
        foreach ($students as &$s) {
            $s['grade'] = Grade::get((int) $s['id'], $courseId, $semId);
        }
        echo json_encode($students);
        break;

    // ----------------------------------------------------------
    // POST: save batch of grades
    // ----------------------------------------------------------
    case 'save':
        $semId    = (int) ($_POST['semester_id'] ?? 0);
        $courseId = (int) ($_POST['course_id']   ?? 0);
        $entries  = $_POST['grades'] ?? [];

        if (!Assignment::exists($professorId, $courseId, $semId)) {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden']);
            exit;
        }

        $validGrades = [0.0, 1.0, 2.0, 3.0, 4.0];
        $saved = 0;

        foreach ($entries as $entry) {
            $studentId = (int) ($entry['student_id'] ?? 0);
            $grade     = isset($entry['grade']) && $entry['grade'] !== '' ? (float) $entry['grade'] : null;

            if ($grade === null || !in_array($grade, $validGrades, true)) {
                continue;
            }

            Grade::upsert($studentId, $courseId, $semId, $professorId, $grade);
            GPA::recompute($studentId, $semId);
            $saved++;
        }

        echo json_encode(['success' => true, 'saved' => $saved]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action']);
}
