<?php
// ============================================================
// controllers/AdminController.php
// ============================================================

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Semester.php';
require_once __DIR__ . '/../models/Course.php';
require_once __DIR__ . '/../models/Enrollment.php';
require_once __DIR__ . '/../models/Assignment.php';
require_once __DIR__ . '/../models/Grade.php';
require_once __DIR__ . '/../models/GPA.php';

class AdminController {

    public function handle(string $page): void {
        requireRole('admin');

        match ($page) {
            'admin.dashboard'          => $this->dashboard(),
            'admin.semesters'          => $this->semesters(),
            'admin.save_semester'      => $this->saveSemester(),
            'admin.delete_semester'    => $this->deleteSemester(),
            'admin.toggle_semester'    => $this->toggleSemester(),
            'admin.courses'            => $this->courses(),
            'admin.save_course'        => $this->saveCourse(),
            'admin.delete_course'      => $this->deleteCourse(),
            'admin.professors'         => $this->professors(),
            'admin.save_professor'     => $this->saveProfessor(),
            'admin.delete_professor'   => $this->deleteProfessor(),
            'admin.assignments'        => $this->assignments(),
            'admin.save_assignment'    => $this->saveAssignment(),
            'admin.delete_assignment'  => $this->deleteAssignment(),
            'admin.students'           => $this->students(),
            'admin.save_student'       => $this->saveStudent(),
            'admin.delete_student'     => $this->deleteStudent(),
            'admin.enrollments'        => $this->enrollments(),
            'admin.save_enrollments'   => $this->saveEnrollments(),
            default                    => $this->dashboard(),
        };
    }

    // ---- Dashboard ----
    private function dashboard(): void {
        $data = [
            'total_students'    => count(User::getAllByRole('student')),
            'total_professors'  => count(User::getAllByRole('professor')),
            'total_semesters'   => count(Semester::getAll()),
        ];
        include __DIR__ . '/../views/admin/dashboard.php';
    }

    // ---- Semesters ----
    private function semesters(): void {
        $semesters = Semester::getAll();
        include __DIR__ . '/../views/admin/semesters.php';
    }

    private function saveSemester(): void {
        $label = sanitize($_POST['label'] ?? '');
        $year  = sanitize($_POST['academic_year'] ?? '');
        $id    = !empty($_POST['id']) ? (int) $_POST['id'] : null;

        if ($id) {
            Semester::update($id, $label, $year);
        } else {
            Semester::create($label, $year);
        }
        flash('success', 'Semester saved successfully.');
        header('Location: index.php?page=admin.semesters');
        exit;
    }

    private function deleteSemester(): void {
        $id = (int) ($_POST['id'] ?? 0);
        if (Course::countBySemester($id) > 0) {
            flash('danger', 'Cannot delete: semester has linked courses.');
            header('Location: index.php?page=admin.semesters');
            exit;
        }
        Semester::delete($id);
        flash('success', 'Semester deleted.');
        header('Location: index.php?page=admin.semesters');
        exit;
    }

    private function toggleSemester(): void {
        $id = (int) ($_POST['id'] ?? 0);
        Semester::setAllInactive();
        Semester::setActive($id);
        flash('success', 'Active semester updated.');
        header('Location: index.php?page=admin.semesters');
        exit;
    }

    // ---- Courses ----
    private function courses(): void {
        $courses   = Course::getAll();
        $semesters = Semester::getAll();
        include __DIR__ . '/../views/admin/courses.php';
    }

    private function saveCourse(): void {
        $name    = sanitize($_POST['name'] ?? '');
        $credits = (int) ($_POST['credits'] ?? 0);
        $semId   = (int) ($_POST['semester_id'] ?? 0);
        $id      = !empty($_POST['id']) ? (int) $_POST['id'] : null;

        if ($credits <= 0) {
            flash('danger', 'Credits must be a positive integer.');
            header('Location: index.php?page=admin.courses');
            exit;
        }

        if ($id) {
            Course::update($id, $name, $credits, $semId);
        } else {
            Course::create($name, $credits, $semId);
        }
        flash('success', 'Course saved successfully.');
        header('Location: index.php?page=admin.courses');
        exit;
    }

    private function deleteCourse(): void {
        $id = (int) ($_POST['id'] ?? 0);
        if (Grade::countByCourse($id) > 0) {
            flash('danger', 'Cannot delete: grades exist for this course.');
            header('Location: index.php?page=admin.courses');
            exit;
        }
        Course::delete($id);
        flash('success', 'Course deleted.');
        header('Location: index.php?page=admin.courses');
        exit;
    }

    // ---- Professors ----
    private function professors(): void {
        $professors = User::getAllByRole('professor');
        include __DIR__ . '/../views/admin/professors.php';
    }

    private function saveProfessor(): void {
        $name  = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $id    = !empty($_POST['id']) ? (int) $_POST['id'] : null;

        if (User::emailExists($email, $id)) {
            flash('danger', 'Email already in use.');
            header('Location: index.php?page=admin.professors');
            exit;
        }

        if ($id) {
            User::update($id, $name, $email);
            if (!empty($pass)) {
                User::updatePassword($id, password_hash($pass, PASSWORD_BCRYPT));
            }
        } else {
            User::create($name, $email, password_hash($pass, PASSWORD_BCRYPT), 'professor');
        }
        flash('success', 'Professor saved successfully.');
        header('Location: index.php?page=admin.professors');
        exit;
    }

    private function deleteProfessor(): void {
        $id = (int) ($_POST['id'] ?? 0);
        User::delete($id);
        flash('success', 'Professor deleted.');
        header('Location: index.php?page=admin.professors');
        exit;
    }

    // ---- Assignments ----
    private function assignments(): void {
        $assignments = Assignment::getAll();
        $professors  = User::getAllByRole('professor');
        $courses     = Course::getAll();
        $semesters   = Semester::getAll();
        include __DIR__ . '/../views/admin/assignments.php';
    }

    private function saveAssignment(): void {
        $profId   = (int) ($_POST['professor_id'] ?? 0);
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $semId    = (int) ($_POST['semester_id'] ?? 0);

        if (Assignment::courseAlreadyAssigned($courseId, $semId)) {
            flash('danger', 'This course already has a professor for this semester.');
            header('Location: index.php?page=admin.assignments');
            exit;
        }
        Assignment::create($profId, $courseId, $semId);
        flash('success', 'Assignment created.');
        header('Location: index.php?page=admin.assignments');
        exit;
    }

    private function deleteAssignment(): void {
        $id = (int) ($_POST['id'] ?? 0);
        Assignment::delete($id);
        flash('success', 'Assignment removed.');
        header('Location: index.php?page=admin.assignments');
        exit;
    }

    // ---- Students ----
    private function students(): void {
        $students = User::getAllByRole('student');
        include __DIR__ . '/../views/admin/students.php';
    }

    private function saveStudent(): void {
        $name  = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $id    = !empty($_POST['id']) ? (int) $_POST['id'] : null;

        if (User::emailExists($email, $id)) {
            flash('danger', 'Email already in use.');
            header('Location: index.php?page=admin.students');
            exit;
        }

        if ($id) {
            User::update($id, $name, $email);
            if (!empty($pass)) {
                User::updatePassword($id, password_hash($pass, PASSWORD_BCRYPT));
            }
        } else {
            User::create($name, $email, password_hash($pass, PASSWORD_BCRYPT), 'student');
        }
        flash('success', 'Student saved successfully.');
        header('Location: index.php?page=admin.students');
        exit;
    }

    private function deleteStudent(): void {
        $id = (int) ($_POST['id'] ?? 0);
        // Remove linked data first
        Grade::deleteByStudent($id);
        GPA::deleteByStudent($id);
        Enrollment::deleteAllForStudent($id);
        User::delete($id);
        flash('success', 'Student deleted.');
        header('Location: index.php?page=admin.students');
        exit;
    }

    // ---- Enrollments ----
    private function enrollments(): void {
        $students  = User::getAllByRole('student');
        $semesters = Semester::getAll();
        $studentId = (int) ($_GET['student_id'] ?? 0);
        $currentIds = [];
        $selectedStudent = null;

        if ($studentId) {
            $selectedStudent = User::findById($studentId);
            $currentIds      = Enrollment::getSemesterIds($studentId);
        }
        include __DIR__ . '/../views/admin/enrollments.php';
    }

    private function saveEnrollments(): void {
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $newIds    = array_map('intval', $_POST['semester_ids'] ?? []);
        $currentIds = array_map('intval', Enrollment::getSemesterIds($studentId));

        $toAdd    = array_diff($newIds, $currentIds);
        $toRemove = array_diff($currentIds, $newIds);
        $warnings = [];

        foreach ($toAdd as $semId) {
            Enrollment::create($studentId, $semId);
        }

        foreach ($toRemove as $semId) {
            if (Grade::countByStudentSemester($studentId, $semId) > 0) {
                $warnings[] = "Semester #$semId skipped (grades exist).";
            } else {
                Enrollment::delete($studentId, $semId);
            }
        }

        $msg = 'Enrollments updated.';
        if ($warnings) {
            $msg .= ' Warning: ' . implode(' ', $warnings);
            flash('warning', $msg);
        } else {
            flash('success', $msg);
        }

        header("Location: index.php?page=admin.enrollments&student_id=$studentId");
        exit;
    }
}
