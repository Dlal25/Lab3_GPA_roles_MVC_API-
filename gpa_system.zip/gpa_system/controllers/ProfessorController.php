<?php
// ============================================================
// controllers/ProfessorController.php
// ============================================================

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Assignment.php';

class ProfessorController {

    public function handle(string $page): void {
        requireRole('professor');

        match ($page) {
            'professor.grades' => $this->grades(),
            default            => $this->grades(),
        };
    }

    private function grades(): void {
        $professorId = (int) $_SESSION['user_id'];
        $semesters   = Assignment::getSemestersByProfessor($professorId);
        include __DIR__ . '/../views/professor/grades.php';
    }
}
