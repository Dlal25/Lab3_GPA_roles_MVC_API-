<?php
// ============================================================
// controllers/StudentController.php
// ============================================================

require_once __DIR__ . '/../config.php';

class StudentController {

    public function handle(string $page): void {
        requireRole('student');

        match ($page) {
            'student.dashboard' => $this->dashboard(),
            'student.history'   => $this->history(),
            default             => $this->dashboard(),
        };
    }

    private function dashboard(): void {
        include __DIR__ . '/../views/student/dashboard.php';
    }

    private function history(): void {
        include __DIR__ . '/../views/student/history.php';
    }
}
