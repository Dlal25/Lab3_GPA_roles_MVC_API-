<?php
// ============================================================
// models/Assignment.php
// ============================================================

require_once __DIR__ . '/../config.php';

class Assignment {

    public static function getAll(): array {
        $sql = 'SELECT a.*, u.name AS professor_name, c.name AS course_name,
                       s.label AS semester_label, s.academic_year
                FROM assignments a
                JOIN users u       ON u.id = a.professor_id
                JOIN courses c     ON c.id = a.course_id
                JOIN semesters s   ON s.id = a.semester_id
                ORDER BY s.academic_year DESC, s.label, c.name';
        return getPDO()->query($sql)->fetchAll();
    }

    public static function getCoursesByProfessorSemester(int $professorId, int $semesterId): array {
        $sql = 'SELECT c.id, c.name, c.credits
                FROM assignments a
                JOIN courses c ON c.id = a.course_id
                WHERE a.professor_id = ? AND a.semester_id = ?
                ORDER BY c.name';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$professorId, $semesterId]);
        return $stmt->fetchAll();
    }

    public static function getSemestersByProfessor(int $professorId): array {
        $sql = 'SELECT DISTINCT s.*
                FROM assignments a
                JOIN semesters s ON s.id = a.semester_id
                WHERE a.professor_id = ?
                ORDER BY s.academic_year DESC, s.label';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$professorId]);
        return $stmt->fetchAll();
    }

    public static function exists(int $professorId, int $courseId, int $semesterId): bool {
        $stmt = getPDO()->prepare(
            'SELECT id FROM assignments WHERE professor_id = ? AND course_id = ? AND semester_id = ?'
        );
        $stmt->execute([$professorId, $courseId, $semesterId]);
        return (bool) $stmt->fetch();
    }

    public static function courseAlreadyAssigned(int $courseId, int $semesterId): bool {
        $stmt = getPDO()->prepare(
            'SELECT id FROM assignments WHERE course_id = ? AND semester_id = ?'
        );
        $stmt->execute([$courseId, $semesterId]);
        return (bool) $stmt->fetch();
    }

    public static function create(int $professorId, int $courseId, int $semesterId): void {
        $stmt = getPDO()->prepare(
            'INSERT INTO assignments (professor_id, course_id, semester_id) VALUES (?, ?, ?)'
        );
        $stmt->execute([$professorId, $courseId, $semesterId]);
    }

    public static function delete(int $id): void {
        $stmt = getPDO()->prepare('DELETE FROM assignments WHERE id = ?');
        $stmt->execute([$id]);
    }
}
