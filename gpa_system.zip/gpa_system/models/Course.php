<?php
// ============================================================
// models/Course.php
// ============================================================

require_once __DIR__ . '/../config.php';

class Course {

    public static function getAll(): array {
        $sql = 'SELECT c.*, s.label AS semester_label, s.academic_year
                FROM courses c
                JOIN semesters s ON s.id = c.semester_id
                ORDER BY s.academic_year DESC, s.label, c.name';
        return getPDO()->query($sql)->fetchAll();
    }

    public static function getBySemester(int $semesterId): array {
        $stmt = getPDO()->prepare('SELECT * FROM courses WHERE semester_id = ? ORDER BY name');
        $stmt->execute([$semesterId]);
        return $stmt->fetchAll();
    }

    public static function findById(int $id): ?array {
        $stmt = getPDO()->prepare('SELECT * FROM courses WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function countBySemester(int $semesterId): int {
        $stmt = getPDO()->prepare('SELECT COUNT(*) FROM courses WHERE semester_id = ?');
        $stmt->execute([$semesterId]);
        return (int) $stmt->fetchColumn();
    }

    public static function create(string $name, int $credits, int $semesterId): void {
        $stmt = getPDO()->prepare('INSERT INTO courses (name, credits, semester_id) VALUES (?, ?, ?)');
        $stmt->execute([$name, $credits, $semesterId]);
    }

    public static function update(int $id, string $name, int $credits, int $semesterId): void {
        $stmt = getPDO()->prepare('UPDATE courses SET name = ?, credits = ?, semester_id = ? WHERE id = ?');
        $stmt->execute([$name, $credits, $semesterId, $id]);
    }

    public static function delete(int $id): void {
        $stmt = getPDO()->prepare('DELETE FROM courses WHERE id = ?');
        $stmt->execute([$id]);
    }
}
