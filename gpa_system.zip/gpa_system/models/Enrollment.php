<?php
// ============================================================
// models/Enrollment.php
// ============================================================

require_once __DIR__ . '/../config.php';

class Enrollment {

    public static function getSemesterIds(int $studentId): array {
        $stmt = getPDO()->prepare('SELECT semester_id FROM enrollments WHERE student_id = ?');
        $stmt->execute([$studentId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public static function getSemestersByStudent(int $studentId): array {
        $sql = 'SELECT s.* FROM semesters s
                JOIN enrollments e ON e.semester_id = s.id
                WHERE e.student_id = ?
                ORDER BY s.academic_year DESC, s.label';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$studentId]);
        return $stmt->fetchAll();
    }

    public static function getStudentsBySemester(int $semesterId): array {
        $sql = 'SELECT u.id, u.name, u.email
                FROM users u
                JOIN enrollments e ON e.student_id = u.id
                WHERE e.semester_id = ?
                ORDER BY u.name';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$semesterId]);
        return $stmt->fetchAll();
    }

    public static function exists(int $studentId, int $semesterId): bool {
        $stmt = getPDO()->prepare(
            'SELECT id FROM enrollments WHERE student_id = ? AND semester_id = ?'
        );
        $stmt->execute([$studentId, $semesterId]);
        return (bool) $stmt->fetch();
    }

    public static function create(int $studentId, int $semesterId): void {
        $stmt = getPDO()->prepare(
            'INSERT IGNORE INTO enrollments (student_id, semester_id) VALUES (?, ?)'
        );
        $stmt->execute([$studentId, $semesterId]);
    }

    public static function delete(int $studentId, int $semesterId): void {
        $stmt = getPDO()->prepare(
            'DELETE FROM enrollments WHERE student_id = ? AND semester_id = ?'
        );
        $stmt->execute([$studentId, $semesterId]);
    }

    public static function deleteAllForStudent(int $studentId): void {
        $stmt = getPDO()->prepare('DELETE FROM enrollments WHERE student_id = ?');
        $stmt->execute([$studentId]);
    }
}
