<?php
// ============================================================
// models/GPA.php
// ============================================================

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Grade.php';

class GPA {

    /**
     * Recompute weighted GPA for a student in a semester and upsert into gpa_records.
     * GPA = SUM(grade * credits) / SUM(credits)
     */
    public static function recompute(int $studentId, int $semesterId): void {
        $rows = Grade::getAllWithCredits($studentId, $semesterId);

        $totalPoints  = 0.0;
        $totalCredits = 0;

        foreach ($rows as $row) {
            $totalPoints  += (float) $row['grade'] * (int) $row['credits'];
            $totalCredits += (int) $row['credits'];
        }

        if ($totalCredits > 0) {
            $gpa = round($totalPoints / $totalCredits, 2);
            self::upsert($studentId, $semesterId, $gpa);
        }
    }

    public static function get(int $studentId, int $semesterId): ?array {
        $stmt = getPDO()->prepare(
            'SELECT * FROM gpa_records WHERE student_id = ? AND semester_id = ?'
        );
        $stmt->execute([$studentId, $semesterId]);
        return $stmt->fetch() ?: null;
    }

    public static function upsert(int $studentId, int $semesterId, float $gpa): void {
        $sql = 'INSERT INTO gpa_records (student_id, semester_id, gpa)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE gpa = VALUES(gpa)';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$studentId, $semesterId, $gpa]);
    }

    public static function deleteByStudent(int $studentId): void {
        $stmt = getPDO()->prepare('DELETE FROM gpa_records WHERE student_id = ?');
        $stmt->execute([$studentId]);
    }

    /**
     * Bootstrap alert class based on GPA value.
     */
    public static function alertClass(float $gpa): string {
        return match (true) {
            $gpa >= 3.7 => 'alert-success',
            $gpa >= 3.0 => 'alert-info',
            $gpa >= 2.0 => 'alert-warning',
            default     => 'alert-danger',
        };
    }
}
