<?php
// ============================================================
// models/Grade.php
// ============================================================

require_once __DIR__ . '/../config.php';

class Grade {

    public static function get(int $studentId, int $courseId, int $semesterId): ?float {
        $stmt = getPDO()->prepare(
            'SELECT grade FROM grades WHERE student_id = ? AND course_id = ? AND semester_id = ?'
        );
        $stmt->execute([$studentId, $courseId, $semesterId]);
        $val = $stmt->fetchColumn();
        return $val !== false ? (float) $val : null;
    }

    public static function upsert(int $studentId, int $courseId, int $semesterId, int $professorId, float $grade): void {
        $sql = 'INSERT INTO grades (student_id, course_id, semester_id, professor_id, grade)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE grade = VALUES(grade), professor_id = VALUES(professor_id)';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$studentId, $courseId, $semesterId, $professorId, $grade]);
    }

    public static function getAllWithCredits(int $studentId, int $semesterId): array {
        $sql = 'SELECT g.grade, c.credits
                FROM grades g
                JOIN courses c ON c.id = g.course_id
                WHERE g.student_id = ? AND g.semester_id = ?';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$studentId, $semesterId]);
        return $stmt->fetchAll();
    }

    public static function getAllWithDetailsByStudent(int $studentId): array {
        $sql = 'SELECT s.label AS semester_label, s.academic_year,
                       c.name AS course_name, c.credits,
                       g.grade
                FROM grades g
                JOIN courses c   ON c.id = g.course_id
                JOIN semesters s ON s.id = g.semester_id
                WHERE g.student_id = ?
                ORDER BY s.academic_year, s.label, c.name';
        $stmt = getPDO()->prepare($sql);
        $stmt->execute([$studentId]);
        return $stmt->fetchAll();
    }

    public static function countByCourse(int $courseId): int {
        $stmt = getPDO()->prepare('SELECT COUNT(*) FROM grades WHERE course_id = ?');
        $stmt->execute([$courseId]);
        return (int) $stmt->fetchColumn();
    }

    public static function countByStudentSemester(int $studentId, int $semesterId): int {
        $stmt = getPDO()->prepare(
            'SELECT COUNT(*) FROM grades WHERE student_id = ? AND semester_id = ?'
        );
        $stmt->execute([$studentId, $semesterId]);
        return (int) $stmt->fetchColumn();
    }

    public static function deleteByStudent(int $studentId): void {
        $stmt = getPDO()->prepare('DELETE FROM grades WHERE student_id = ?');
        $stmt->execute([$studentId]);
    }
}
