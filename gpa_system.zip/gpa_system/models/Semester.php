<?php
// ============================================================
// models/Semester.php
// ============================================================

require_once __DIR__ . '/../config.php';

class Semester {

    public static function getAll(): array {
        return getPDO()->query('SELECT * FROM semesters ORDER BY academic_year DESC, label')->fetchAll();
    }

    public static function getActive(): ?array {
        $stmt = getPDO()->query('SELECT * FROM semesters WHERE is_active = 1 LIMIT 1');
        return $stmt->fetch() ?: null;
    }

    public static function findById(int $id): ?array {
        $stmt = getPDO()->prepare('SELECT * FROM semesters WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(string $label, string $academicYear): void {
        $stmt = getPDO()->prepare('INSERT INTO semesters (label, academic_year) VALUES (?, ?)');
        $stmt->execute([$label, $academicYear]);
    }

    public static function update(int $id, string $label, string $academicYear): void {
        $stmt = getPDO()->prepare('UPDATE semesters SET label = ?, academic_year = ? WHERE id = ?');
        $stmt->execute([$label, $academicYear, $id]);
    }

    public static function delete(int $id): void {
        $stmt = getPDO()->prepare('DELETE FROM semesters WHERE id = ?');
        $stmt->execute([$id]);
    }

    public static function setAllInactive(): void {
        getPDO()->query('UPDATE semesters SET is_active = 0');
    }

    public static function setActive(int $id): void {
        $stmt = getPDO()->prepare('UPDATE semesters SET is_active = 1 WHERE id = ?');
        $stmt->execute([$id]);
    }
}
