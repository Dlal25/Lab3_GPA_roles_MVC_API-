<?php
// ============================================================
// models/User.php
// ============================================================

require_once __DIR__ . '/../config.php';

class User {

    public static function findByEmail(string $email): ?array {
        $stmt = getPDO()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        return $stmt->fetch() ?: null;
    }

    public static function findById(int $id): ?array {
        $stmt = getPDO()->prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function getAllByRole(string $role): array {
        $stmt = getPDO()->prepare('SELECT id, name, email, created_at FROM users WHERE role = ? ORDER BY name');
        $stmt->execute([$role]);
        return $stmt->fetchAll();
    }

    public static function emailExists(string $email, ?int $excludeId = null): bool {
        if ($excludeId) {
            $stmt = getPDO()->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
            $stmt->execute([$email, $excludeId]);
        } else {
            $stmt = getPDO()->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
        }
        return (bool) $stmt->fetch();
    }

    public static function create(string $name, string $email, string $hashedPassword, string $role): void {
        $stmt = getPDO()->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $stmt->execute([$name, $email, $hashedPassword, $role]);
    }

    public static function update(int $id, string $name, string $email): void {
        $stmt = getPDO()->prepare('UPDATE users SET name = ?, email = ? WHERE id = ?');
        $stmt->execute([$name, $email, $id]);
    }

    public static function updatePassword(int $id, string $hashedPassword): void {
        $stmt = getPDO()->prepare('UPDATE users SET password = ? WHERE id = ?');
        $stmt->execute([$hashedPassword, $id]);
    }

    public static function delete(int $id): void {
        $stmt = getPDO()->prepare('DELETE FROM users WHERE id = ?');
        $stmt->execute([$id]);
    }
}
