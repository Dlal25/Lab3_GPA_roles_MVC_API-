// ============================================================
// public/js/professor.js — AJAX grade entry
// ============================================================

$(document).ready(function () {

    // ---- Step 1: Semester selected → load courses ----
    $('#semesterSelect').change(function () {
        var semId = $(this).val();
        if (!semId) return;

        $.get('api/grades.php', { action: 'courses', semester_id: semId }, function (data) {
            var opts = '<option value="">-- Select Course --</option>';
            $.each(data, function (i, c) {
                opts += '<option value="' + c.id + '">' + c.name + ' (' + c.credits + ' cr)</option>';
            });
            $('#courseSelect').html(opts).prop('disabled', false);
            $('#gradeTable').hide();
            $('#feedback').html('');
        }, 'json').fail(function () {
            $('#feedback').html('<div class="alert alert-danger">Failed to load courses.</div>');
        });
    });

    // ---- Step 2: Course selected → load students ----
    $('#courseSelect').change(function () {
        var semId    = $('#semesterSelect').val();
        var courseId = $(this).val();
        if (!courseId) return;

        $.get('api/grades.php',
            { action: 'students', semester_id: semId, course_id: courseId },
            function (students) {
                if (students.error) {
                    $('#feedback').html('<div class="alert alert-danger">' + students.error + '</div>');
                    return;
                }

                var html = '<tbody>';
                $.each(students, function (i, s) {
                    var gradeVal = s.grade !== null ? s.grade : '';
                    html += '<tr>'
                        + '<td>' + s.name + '</td>'
                        + '<td>' + s.id + '</td>'
                        + '<td>'
                        +   '<select name="grade_' + s.id + '" '
                        +   'data-student="' + s.id + '" '
                        +   'class="form-select form-select-sm grade-input" style="width:120px">'
                        +   buildOptions(gradeVal)
                        +   '</select>'
                        + '</td></tr>';
                });
                html += '</tbody>';

                $('#gradeTable').find('tbody').replaceWith(html);
                $('#gradeTable').show();
                $('#feedback').html('');
            }, 'json'
        ).fail(function () {
            $('#feedback').html('<div class="alert alert-danger">Failed to load students.</div>');
        });
    });

    // ---- Step 3: Save grades ----
    $('#saveBtn').click(function () {
        var semId    = $('#semesterSelect').val();
        var courseId = $('#courseSelect').val();
        var grades   = [];

        $('.grade-input').each(function () {
            grades.push({
                student_id: $(this).data('student'),
                grade:      $(this).val()
            });
        });

        $.post('api/grades.php',
            { action: 'save', semester_id: semId, course_id: courseId, grades: grades },
            function (res) {
                var cls = res.success ? 'alert-success' : 'alert-danger';
                var msg = res.success
                    ? '✅ ' + res.saved + ' grade(s) saved successfully.'
                    : '❌ ' + res.error;
                $('#feedback').html('<div class="alert ' + cls + '">' + msg + '</div>');
            }, 'json'
        ).fail(function () {
            $('#feedback').html('<div class="alert alert-danger">Save failed.</div>');
        });
    });

    // ---- Build grade option list ----
    function buildOptions(selected) {
        var opts = [
            ['', '-- Grade --'],
            ['4.0', 'A  (4.0)'],
            ['3.0', 'B  (3.0)'],
            ['2.0', 'C  (2.0)'],
            ['1.0', 'D  (1.0)'],
            ['0.0', 'F  (0.0)']
        ];
        return opts.map(function (o) {
            return '<option value="' + o[0] + '"'
                + (o[0] == selected ? ' selected' : '') + '>'
                + o[1] + '</option>';
        }).join('');
    }
});
