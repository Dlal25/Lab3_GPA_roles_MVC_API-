// ============================================================
// public/js/student.js — AJAX GPA display
// ============================================================

// ---- Load current semester grades ----
function loadCurrentGrades() {
    $.get('api/gpa.php', { action: 'current' }, function (data) {
        if (data.error) {
            $('#gradeContent').html('<div class="alert alert-warning">' + data.error + '</div>');
            return;
        }

        var sem  = data.semester;
        var gpa  = data.gpa;
        var cls  = gpaAlertClass(gpa);

        var html = '<h6>' + sem.label + ' — ' + sem.academic_year + '</h6>';

        // GPA badge
        if (gpa !== null) {
            html += '<div class="alert ' + cls + ' fw-bold">GPA: ' + gpa.toFixed(2) + ' — ' + gpaLabel(gpa) + '</div>';
        } else {
            html += '<div class="alert alert-secondary">GPA not yet computed (no grades entered).</div>';
        }

        // Grades table
        html += '<table class="table table-bordered"><thead class="table-dark"><tr>'
            + '<th>Course</th><th>Credits</th><th>Grade</th><th>Grade Points</th>'
            + '</tr></thead><tbody>';

        $.each(data.courses, function (i, c) {
            html += '<tr>'
                + '<td>' + c.name + '</td>'
                + '<td>' + c.credits + '</td>'
                + '<td>' + (c.grade !== null ? gradeLetterBadge(c.grade) : '<span class="badge bg-secondary">Pending</span>') + '</td>'
                + '<td>' + (c.grade_points !== null ? c.grade_points.toFixed(1) : '—') + '</td>'
                + '</tr>';
        });

        html += '</tbody></table>';
        $('#gradeContent').html(html);

    }, 'json').fail(function () {
        $('#gradeContent').html('<div class="alert alert-danger">Failed to load grades.</div>');
    });
}

// ---- Load history + Chart.js ----
function loadHistory() {
    $.get('api/gpa.php', { action: 'history' }, function (semesters) {
        if (!semesters.length) {
            $('#historyContent').html('<div class="alert alert-info">No enrollment history found.</div>');
            return;
        }

        // Build Chart.js data
        var labels = semesters.map(function (s) { return s.label + ' ' + s.academic_year; });
        var gpas   = semesters.map(function (s) { return s.gpa; });

        var ctx = document.getElementById('gpaChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'GPA',
                    data: gpas,
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13,110,253,0.1)',
                    tension: 0.3,
                    fill: true,
                    pointRadius: 6,
                }]
            },
            options: {
                scales: {
                    y: { min: 0, max: 4, ticks: { stepSize: 0.5 } }
                },
                plugins: { legend: { display: false } }
            }
        });

        // History tables
        var html = '';
        $.each(semesters, function (i, sem) {
            var gpa = sem.gpa;
            var cls = gpaAlertClass(gpa);

            html += '<div class="card shadow-sm mb-3"><div class="card-header d-flex justify-content-between">'
                + '<b>' + sem.label + ' — ' + sem.academic_year + '</b>';

            if (gpa !== null) {
                html += '<span class="badge ' + gpaBadgeClass(gpa) + '">GPA ' + parseFloat(gpa).toFixed(2) + '</span>';
            }

            html += '</div><div class="card-body p-0"><table class="table table-bordered mb-0">'
                + '<thead class="table-secondary"><tr>'
                + '<th>Course</th><th>Credits</th><th>Grade</th><th>Grade Points</th>'
                + '</tr></thead><tbody>';

            $.each(sem.courses, function (j, c) {
                html += '<tr>'
                    + '<td>' + c.name + '</td>'
                    + '<td>' + c.credits + '</td>'
                    + '<td>' + (c.grade !== null ? gradeLetterBadge(c.grade) : '<span class="badge bg-secondary">Pending</span>') + '</td>'
                    + '<td>' + (c.grade_points !== null ? parseFloat(c.grade_points).toFixed(1) : '—') + '</td>'
                    + '</tr>';
            });

            html += '</tbody></table></div></div>';
        });

        $('#historyContent').html(html);

    }, 'json').fail(function () {
        $('#historyContent').html('<div class="alert alert-danger">Failed to load history.</div>');
    });
}

// ---- Helpers ----
function gpaAlertClass(gpa) {
    if (gpa === null) return 'alert-secondary';
    if (gpa >= 3.7)   return 'alert-success';
    if (gpa >= 3.0)   return 'alert-info';
    if (gpa >= 2.0)   return 'alert-warning';
    return 'alert-danger';
}

function gpaBadgeClass(gpa) {
    if (gpa >= 3.7) return 'bg-success';
    if (gpa >= 3.0) return 'bg-info text-dark';
    if (gpa >= 2.0) return 'bg-warning text-dark';
    return 'bg-danger';
}

function gpaLabel(gpa) {
    if (gpa >= 3.7) return 'Distinction';
    if (gpa >= 3.0) return 'Merit';
    if (gpa >= 2.0) return 'Pass';
    return 'Fail';
}

function gradeLetterBadge(grade) {
    var map = { 4.0: ['A', 'bg-success'], 3.0: ['B', 'bg-primary'],
                2.0: ['C', 'bg-warning text-dark'], 1.0: ['D', 'bg-secondary'],
                0.0: ['F', 'bg-danger'] };
    var g   = parseFloat(grade);
    var info = map[g] || [grade, 'bg-secondary'];
    return '<span class="badge ' + info[1] + '">' + info[0] + ' (' + g.toFixed(1) + ')</span>';
}
