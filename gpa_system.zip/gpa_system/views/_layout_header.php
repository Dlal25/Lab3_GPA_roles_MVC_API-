<?php
// views/_layout_header.php
// Usage: include with $title and $role variables set
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($title ?? 'GPA System', ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">🎓 GPA System</a>
        <div class="navbar-nav ms-auto">
            <span class="navbar-text text-light me-3">
                <?= htmlspecialchars($_SESSION['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                <span class="badge bg-secondary ms-1"><?= ucfirst($_SESSION['role'] ?? '') ?></span>
            </span>
            <a class="nav-link text-light" href="index.php?page=logout">Logout</a>
        </div>
    </div>
</nav>

<?php if ($role === 'admin'): ?>
<!-- Admin nav tabs -->
<div class="bg-white border-bottom">
    <div class="container-fluid">
        <ul class="nav nav-tabs border-0">
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.dashboard">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.semesters">Semesters</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.courses">Courses</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.professors">Professors</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.assignments">Assignments</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.students">Students</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=admin.enrollments">Enrollments</a></li>
        </ul>
    </div>
</div>
<?php elseif ($role === 'student'): ?>
<div class="bg-white border-bottom">
    <div class="container-fluid">
        <ul class="nav nav-tabs border-0">
            <li class="nav-item"><a class="nav-link" href="index.php?page=student.dashboard">My Grades</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=student.history">GPA History</a></li>
        </ul>
    </div>
</div>
<?php endif; ?>

<div class="container-fluid py-4">

<?php
// Flash message
$f = getFlash();
if ($f):
?>
<div class="alert alert-<?= $f['type'] ?> alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($f['msg'], ENT_QUOTES, 'UTF-8') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
