<?php
$title = 'Assignments — Admin';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header"><b>Assign Professor to Course</b></div>
            <div class="card-body">
                <form method="POST" action="index.php?page=admin.save_assignment">
                    <div class="mb-3">
                        <label class="form-label">Professor</label>
                        <select name="professor_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($professors as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Course</label>
                        <select name="course_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($courses as $c): ?>
                                <option value="<?= $c['id'] ?>">
                                    <?= htmlspecialchars($c['name'] . ' (' . $c['semester_label'] . ' ' . $c['academic_year'] . ')', ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Semester</label>
                        <select name="semester_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($semesters as $s): ?>
                                <option value="<?= $s['id'] ?>">
                                    <?= htmlspecialchars($s['label'] . ' ' . $s['academic_year'], ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Assign</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header"><b>All Assignments</b></div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-dark">
                        <tr><th>Professor</th><th>Course</th><th>Semester</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($assignments as $a): ?>
                        <tr>
                            <td><?= htmlspecialchars($a['professor_name'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($a['course_name'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($a['semester_label'] . ' ' . $a['academic_year'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <form method="POST" action="index.php?page=admin.delete_assignment" class="d-inline"
                                      onsubmit="return confirm('Remove this assignment?')">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                    <button class="btn btn-sm btn-danger">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
