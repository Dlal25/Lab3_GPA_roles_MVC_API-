<?php
$title = 'Courses — Admin';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header"><b>Add / Edit Course</b></div>
            <div class="card-body">
                <form method="POST" action="index.php?page=admin.save_course" id="courseForm">
                    <input type="hidden" name="id" id="courseId">
                    <div class="mb-3">
                        <label class="form-label">Course Name</label>
                        <input type="text" name="name" id="courseName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Credits</label>
                        <input type="number" name="credits" id="courseCredits" class="form-control" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Semester</label>
                        <select name="semester_id" id="courseSem" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($semesters as $s): ?>
                                <option value="<?= $s['id'] ?>">
                                    <?= htmlspecialchars($s['label'] . ' ' . $s['academic_year'], ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header"><b>All Courses</b></div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-dark">
                        <tr><th>Name</th><th>Credits</th><th>Semester</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($courses as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= $c['credits'] ?></td>
                            <td><?= htmlspecialchars($c['semester_label'] . ' ' . $c['academic_year'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning"
                                    onclick="document.getElementById('courseId').value='<?= $c['id'] ?>';
                                             document.getElementById('courseName').value='<?= htmlspecialchars($c['name'], ENT_QUOTES) ?>';
                                             document.getElementById('courseCredits').value='<?= $c['credits'] ?>';
                                             document.getElementById('courseSem').value='<?= $c['semester_id'] ?>';">
                                    Edit
                                </button>
                                <form method="POST" action="index.php?page=admin.delete_course" class="d-inline"
                                      onsubmit="return confirm('Delete this course?')">
                                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
