<?php
$title = 'Admin Dashboard';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<h4 class="mb-4">Dashboard</h4>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card text-white bg-primary shadow">
            <div class="card-body text-center">
                <h1><?= $data['total_students'] ?></h1>
                <p class="mb-0">Students</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-success shadow">
            <div class="card-body text-center">
                <h1><?= $data['total_professors'] ?></h1>
                <p class="mb-0">Professors</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info shadow">
            <div class="card-body text-center">
                <h1><?= $data['total_semesters'] ?></h1>
                <p class="mb-0">Semesters</p>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
