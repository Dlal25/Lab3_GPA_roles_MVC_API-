<?php
$title = 'Enrollments — Admin';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<div class="row">
    <!-- Student selector -->
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header"><b>Select Student</b></div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush">
                    <?php foreach ($students as $s): ?>
                        <a href="index.php?page=admin.enrollments&student_id=<?= $s['id'] ?>"
                           class="list-group-item list-group-item-action <?= $selectedStudent && $selectedStudent['id'] == $s['id'] ? 'active' : '' ?>">
                            <?= htmlspecialchars($s['name'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- Enrollment form -->
    <div class="col-md-8">
        <?php if ($selectedStudent): ?>
        <div class="card shadow-sm">
            <div class="card-header">
                <b>Enrollments for: <?= htmlspecialchars($selectedStudent['name'], ENT_QUOTES, 'UTF-8') ?></b>
            </div>
            <div class="card-body">
                <form method="POST" action="index.php?page=admin.save_enrollments">
                    <input type="hidden" name="student_id" value="<?= $selectedStudent['id'] ?>">
                    <?php foreach ($semesters as $s): ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox"
                                   name="semester_ids[]"
                                   value="<?= $s['id'] ?>"
                                   id="sem<?= $s['id'] ?>"
                                   <?= in_array($s['id'], $currentIds) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="sem<?= $s['id'] ?>">
                                <?= htmlspecialchars($s['label'] . ' ' . $s['academic_year'], ENT_QUOTES, 'UTF-8') ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                    <button type="submit" class="btn btn-primary mt-3">Save Enrollments</button>
                </form>
            </div>
        </div>
        <?php else: ?>
            <div class="alert alert-info">Select a student from the list to manage their enrollments.</div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
