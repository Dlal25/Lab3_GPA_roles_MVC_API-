<?php
$title = 'Professors — Admin';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header"><b>Add / Edit Professor</b></div>
            <div class="card-body">
                <form method="POST" action="index.php?page=admin.save_professor" id="profForm">
                    <input type="hidden" name="id" id="profId">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" id="profName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" id="profEmail" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password <small class="text-muted">(leave blank to keep)</small></label>
                        <input type="password" name="password" id="profPass" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header"><b>All Professors</b></div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-dark">
                        <tr><th>Name</th><th>Email</th><th>Created</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($professors as $p): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($p['email'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= date('Y-m-d', strtotime($p['created_at'])) ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning"
                                    onclick="document.getElementById('profId').value='<?= $p['id'] ?>';
                                             document.getElementById('profName').value='<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>';
                                             document.getElementById('profEmail').value='<?= htmlspecialchars($p['email'], ENT_QUOTES) ?>';
                                             document.getElementById('profPass').value='';">
                                    Edit
                                </button>
                                <form method="POST" action="index.php?page=admin.delete_professor" class="d-inline"
                                      onsubmit="return confirm('Delete this professor?')">
                                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
