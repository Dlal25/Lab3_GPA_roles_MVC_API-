<?php
$title = 'Semesters — Admin';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<div class="row">
    <!-- Form -->
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header"><b>Add / Edit Semester</b></div>
            <div class="card-body">
                <form method="POST" action="index.php?page=admin.save_semester" id="semForm">
                    <input type="hidden" name="id" id="semId">
                    <div class="mb-3">
                        <label class="form-label">Label (e.g. S1)</label>
                        <input type="text" name="label" id="semLabel" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Academic Year (e.g. 2024/2025)</label>
                        <input type="text" name="academic_year" id="semYear" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save</button>
                    <button type="button" class="btn btn-secondary w-100 mt-2"
                            onclick="document.getElementById('semForm').reset(); document.getElementById('semId').value=''">
                        Clear
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header"><b>All Semesters</b></div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-dark">
                        <tr><th>Label</th><th>Academic Year</th><th>Active</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($semesters as $s): ?>
                        <tr>
                            <td><?= htmlspecialchars($s['label'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($s['academic_year'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <?php if ($s['is_active']): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <form method="POST" action="index.php?page=admin.toggle_semester" class="d-inline">
                                        <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                        <button class="btn btn-sm btn-outline-success">Set Active</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-warning"
                                    onclick="document.getElementById('semId').value='<?= $s['id'] ?>';
                                             document.getElementById('semLabel').value='<?= htmlspecialchars($s['label'], ENT_QUOTES) ?>';
                                             document.getElementById('semYear').value='<?= htmlspecialchars($s['academic_year'], ENT_QUOTES) ?>';">
                                    Edit
                                </button>
                                <form method="POST" action="index.php?page=admin.delete_semester" class="d-inline"
                                      onsubmit="return confirm('Delete this semester?')">
                                    <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
