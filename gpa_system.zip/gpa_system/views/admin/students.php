<?php
$title = 'Students — Admin';
$role  = 'admin';
include __DIR__ . '/../_layout_header.php';
?>

<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header"><b>Add / Edit Student</b></div>
            <div class="card-body">
                <form method="POST" action="index.php?page=admin.save_student" id="stuForm">
                    <input type="hidden" name="id" id="stuId">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" id="stuName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" id="stuEmail" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password <small class="text-muted">(leave blank to keep)</small></label>
                        <input type="password" name="password" id="stuPass" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header"><b>All Students</b></div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-dark">
                        <tr><th>Name</th><th>Email</th><th>Created</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($students as $s): ?>
                        <tr>
                            <td><?= htmlspecialchars($s['name'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($s['email'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= date('Y-m-d', strtotime($s['created_at'])) ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning"
                                    onclick="document.getElementById('stuId').value='<?= $s['id'] ?>';
                                             document.getElementById('stuName').value='<?= htmlspecialchars($s['name'], ENT_QUOTES) ?>';
                                             document.getElementById('stuEmail').value='<?= htmlspecialchars($s['email'], ENT_QUOTES) ?>';
                                             document.getElementById('stuPass').value='';">
                                    Edit
                                </button>
                                <a href="index.php?page=admin.enrollments&student_id=<?= $s['id'] ?>"
                                   class="btn btn-sm btn-info">Enroll</a>
                                <form method="POST" action="index.php?page=admin.delete_student" class="d-inline"
                                      onsubmit="return confirm('Delete student and all their data?')">
                                    <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
