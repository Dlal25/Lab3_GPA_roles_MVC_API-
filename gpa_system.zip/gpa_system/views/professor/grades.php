<?php
$title = 'Grade Entry — Professor';
$role  = 'professor';
include __DIR__ . '/../_layout_header.php';
?>

<h5 class="mb-4">Grade Entry</h5>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <div class="row g-3 align-items-end">
            <!-- Semester dropdown (server-side populated) -->
            <div class="col-md-4">
                <label class="form-label">Semester</label>
                <select id="semesterSelect" class="form-select">
                    <option value="">-- Select Semester --</option>
                    <?php foreach ($semesters as $s): ?>
                        <option value="<?= $s['id'] ?>">
                            <?= htmlspecialchars($s['label'] . ' ' . $s['academic_year'], ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Course dropdown (AJAX populated) -->
            <div class="col-md-4">
                <label class="form-label">Course</label>
                <select id="courseSelect" class="form-select" disabled>
                    <option value="">-- Select Course --</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Feedback alert -->
<div id="feedback"></div>

<!-- Student grade table -->
<div id="gradeTable" style="display:none;">
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr><th>Student Name</th><th>ID</th><th>Grade</th></tr>
                </thead>
                <tbody></tbody>
            </table>
            <button id="saveBtn" class="btn btn-success">💾 Save Grades</button>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
<script src="public/js/professor.js"></script>
