<?php
$title = 'My Grades — Student';
$role  = 'student';
include __DIR__ . '/../_layout_header.php';
?>

<h5 class="mb-4">Current Semester Grades</h5>

<div id="feedback"></div>
<div id="gradeContent">
    <p class="text-muted">Loading grades...</p>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
<script src="public/js/student.js"></script>
<script>
    loadCurrentGrades();
</script>
