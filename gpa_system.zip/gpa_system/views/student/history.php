<?php
$title = 'GPA History — Student';
$role  = 'student';
include __DIR__ . '/../_layout_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="mb-0">GPA History</h5>
    <a href="api/gpa.php?action=export" class="btn btn-outline-success btn-sm">📥 Export CSV</a>
</div>

<!-- Chart.js GPA line chart -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <canvas id="gpaChart" height="100"></canvas>
    </div>
</div>

<!-- History table -->
<div id="historyContent">
    <p class="text-muted">Loading history...</p>
</div>

<?php include __DIR__ . '/../_layout_footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="public/js/student.js"></script>
<script>
    loadHistory();
</script>
